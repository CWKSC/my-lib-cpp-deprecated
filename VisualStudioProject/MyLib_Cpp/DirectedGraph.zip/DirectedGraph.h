#pragma once

#include <iostream>
#include <unordered_map>
#include <vector>
#include <list>

template<typename EdgeValue = int, typename Node = int>
struct DirectedGraph
{
    using ToNodeEdge = std::unordered_map<Node, EdgeValue>;
    using ToEdge = std::pair<Node, EdgeValue>;
    using Edges = std::unordered_map<Node, ToNodeEdge>;

    Edges edges;
    DirectedGraph() {}
    DirectedGraph(Edges edges) {
        this->edges = edges;
    }
    void addEdge(Node a, Node b, EdgeValue value) {
        if (edges.count(a) == 0) {
            edges.insert({ a, ToNodeEdge() });
        }
        if (edges[a].count(b) == 0) {
            edges[a].insert({ b, value });
        }
        else {
            edges[a][b] = value;
        }
    }

    std::vector<ToEdge> getToEdge(Node id) {
        std::vector<ToEdge> v;
        if (edges.count(id) != 0) {
            for (ToEdge toEdge : edges[id]) {
                v.push_back(toEdge);
            }
        }
        return v;
    }

    std::vector<Node> getNeighborsNode(Node id) {
        std::vector<Node> v;
        if (edges.count(id) != 0) {
            for (ToEdge toEdge : edges[id]) {
                v.push_back(toEdge.first);
            }
        }
        return v;
    }

    void printAllEdge(int max) {
        std::cout << '\n';
        for (int i = 0; i <= max; i++) {
            std::vector<ToEdge> toEdges = getToEdge(i);
            for (ToEdge toEdge : toEdges)
            {
                Node other = toEdge.first;
                EdgeValue value = toEdge.second;
                std::cout << i << " to " << other << " weight " << value << '\n';
            }
            std::cout << '\n';
        }
        std::cout << '\n';
    }

    void printAllNeighborsNode(int max) {
        std::cout << '\n';
        for (int i = 0; i <= max; i++) {
            std::vector<Node> neighborsNode = getNeighborsNode(i);
            std::cout << i << ": ";
            for (Node node : neighborsNode)
            {
                std::cout << node << " ";
            }
            std::cout << '\n';
        }
        std::cout << '\n';
    }

    static void test() {
        DirectedGraph<> graph;
        graph.addEdge(0, 1, 16);
        graph.addEdge(0, 2, 13);
        graph.addEdge(1, 3, 12);
        graph.addEdge(1, 2, 10);
        graph.addEdge(2, 1, 4);
        graph.addEdge(2, 4, 14);
        graph.addEdge(3, 2, 9);
        graph.addEdge(3, 5, 20);
        graph.addEdge(4, 3, 7);
        graph.addEdge(4, 5, 4);

        graph.printAllEdge(5);
        graph.printAllNeighborsNode(5);
    }

};



