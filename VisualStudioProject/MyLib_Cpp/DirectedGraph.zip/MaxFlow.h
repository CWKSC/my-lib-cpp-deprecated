#pragma once

#include "DirectedGraph.h"

#include <iostream>
#include <queue>
#include <list>
#include <vector>
#include <unordered_set>

constexpr int maxGraphNodeNumber = 20;

struct MaxFlow
{

    static bool findAugmentingPath(DirectedGraph<> graph, int s, int t, std::list<std::pair<int, int>>& path) {

        int parent[maxGraphNodeNumber]{ -1 };

        std::queue<int> queue;
        queue.push(s);

        std::unordered_set<int> visited;
        visited.insert(s);

        while (!queue.empty()) {
            int node = queue.front();
            queue.pop();

            std::vector<std::pair<int, int>> edges = graph.getToEdge(node);
            for (std::pair<int, int> edge : edges) {
                int other = edge.first;
                int value = edge.second;
                if (!(visited.count(other) == 0 && value > 0)) continue;

                parent[other] = node;
                if (other == t) {
                    int current = t;
                    int parentNode = parent[t];
                    while (current != s) {
                        path.push_front({ parentNode, current });
                        current = parentNode;
                        parentNode = parent[current];
                    }
                    return true;
                }
                queue.push(other);
                visited.insert(other);
            }
        }

        return false;
    }

    static DirectedGraph<> maxFlow(DirectedGraph<> graph, int s, int t) {

        DirectedGraph<> residualNetwork(graph.edges);
        int maxFlow = 0;

        while (true) {
            std::list<std::pair<int, int>> path;
            if (findAugmentingPath(residualNetwork, s, t, path)) {
                int min = 0x3f3f3f3f;
                for (std::pair<int, int> edge : path) {
                    min = std::min(min, residualNetwork.edges[edge.first][edge.second]);
                }
                for (std::pair<int, int> edge : path) {
                    residualNetwork.edges[edge.first][edge.second] -= min;
                }
                maxFlow += min;
            }
            else {
                break;
            }
        }

        std::cout << "maxFlow: " << maxFlow << '\n';

        DirectedGraph<> maxFlowNetwork(graph.edges);
        for (const std::pair<int, std::unordered_map<int, int>>& edge : residualNetwork.edges) {
            for (const std::pair<int, int>& toEdge : edge.second) {
                maxFlowNetwork.edges[edge.first][toEdge.first] -= toEdge.second;
            }
        }

        return maxFlowNetwork;
    }


    static void test() {
        DirectedGraph<> graph;
        graph.addEdge(0, 1, 16);
        graph.addEdge(0, 2, 13);
        graph.addEdge(1, 3, 12);
        graph.addEdge(1, 2, 10);
        graph.addEdge(2, 1, 4);
        graph.addEdge(2, 4, 14);
        graph.addEdge(3, 2, 9);
        graph.addEdge(3, 5, 20);
        graph.addEdge(4, 3, 7);
        graph.addEdge(4, 5, 4);

        graph.printAllEdge(5);
        graph.printAllNeighborsNode(5);

        DirectedGraph<> maxFlowNetwork = maxFlow(graph, 0, 5);
        maxFlowNetwork.printAllEdge(5);
    }

};

