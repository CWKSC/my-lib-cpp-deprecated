#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>
#include <iostream>
#include <utility>
#include <vector>

#include "DistjointSet.h"

#include "UndirectedGraph.h"

template<typename EdgeValue = int>
struct MinimumSpanningTree {
    using Node = int;
    using TwoNode = std::pair<Node, Node>;
    using Edge = std::pair<TwoNode, EdgeValue>;
    using ToEdge = std::pair<int, EdgeValue>;

    static std::vector<Edge> getMinimumSpanningTreeEdge(UndirectedGraph<EdgeValue> graph) {
        std::vector<Edge> allEdge = graph.edges;
        std::sort(allEdge.begin(), allEdge.end(),
            [](const Edge a, const Edge b) {
                return a.second < b.second;
            });
        std::vector<Edge> minimumSpanningTreeEdge;
        DistjointSet disjointSet;
        for (const Edge& edge : allEdge) {
            int nodeA = edge.first.first;
            int nodeB = edge.first.second;
            if (disjointSet.findParent(nodeA) != disjointSet.findParent(nodeB)) {
                disjointSet.unionSet(nodeA, nodeB);
                minimumSpanningTreeEdge.push_back(edge);
            }
        }
        return minimumSpanningTreeEdge;
    }

    static void test() {
        UndirectedGraph<> graph;
        graph.addEdge(0, 1, 5);
        graph.addEdge(0, 3, 3);
        graph.addEdge(3, 6, 5);
        graph.addEdge(6, 7, 3);
        graph.addEdge(7, 5, 1);
        graph.addEdge(7, 8, 4);
        graph.addEdge(0, 5, 1);
        graph.addEdge(5, 4, 0);
        graph.addEdge(1, 4, -3);
        graph.addEdge(4, 2, -1);
        graph.addEdge(4, 8, 5);
        graph.addEdge(8, 8, 2);
        graph.addEdge(5, 8, 2);

        graph.printAllEdge(8);
        graph.printAllNeighborsNode(8);

        std::vector<Edge> minimumSpanningTreeEdge = MinimumSpanningTree::getMinimumSpanningTreeEdge(graph);

        std::cout << "Minimum Spanning Tree Edge:\n";
        for (const Edge& edge : minimumSpanningTreeEdge) {
            std::cout << edge.first.first << " to " << edge.first.second << " weight " << edge.second << '\n';
        }
    }

};


